<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('mycontent'); ?>
	<h4>Home</h4>
	<div>
		This is home.
	</div>
	<div>
		Home is home.
	</div>
	<div>Text messages are used for personal, family, business and social purposes. Governmental and non-governmental organizations use text messaging for communication between colleagues. In the 2010s, the sending of short informal messages has become an accepted part of many cultures, as happened earlier with emailing.</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/Laravel/Navbar/resources/views/home.blade.php ENDPATH**/ ?>