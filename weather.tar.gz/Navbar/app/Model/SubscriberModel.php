<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SubscriberModel extends Model
{
    //
    protected $table = "subscriber";

    protected $fillable = [
    	"subscriberID",
    	"frequency",
    	"statu_s"
    ];

    public $timestamps = false;
}
