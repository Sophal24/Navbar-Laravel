<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class weather extends Model
{
    protected $table = "weather_data";
}
