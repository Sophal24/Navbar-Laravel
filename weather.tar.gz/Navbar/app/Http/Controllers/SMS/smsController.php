<?php

namespace App\Http\Controllers\SMS;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class smsController extends Controller
{
    //

    public function sendSMS(){
    	echo "send sms function";

    	<?php

		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => "https://api.ideamart.io/sms/send",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_POSTFIELDS => "{\n    \"message\":\"Hello From Sophal\",\n    \"destinationAddresses\":[\"tel:+85510345144\"],\n    \"password\":\"password\",\n    \"applicationId\":\"APP_999999\"\n}",
		  CURLOPT_HTTPHEADER => array(
		    "Accept: */*",
		    "Accept-Encoding: gzip, deflate",
		    "Cache-Control: no-cache",
		    "Connection: keep-alive",
		    "Content-Length: 147",
		    "Content-Type: application/json",
		    "Host: api.ideamart.io",
		    "Postman-Token: 18011c88-c08b-4f95-823a-c3b848641176,fd53a90f-28a6-4864-a75a-14ffbb5378ed",
		    "User-Agent: PostmanRuntime/7.16.3",
		    "cache-control: no-cache"
		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		  echo $response;
		}
    }
}
