<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function name(){
    	echo "My name is Thear Sophal";
    }

  //   public function notification(){
  //   	// 1. Get json request  ::::using POST request
		// $data = file_get_contents('php://input'); // string
		// $arr_data = json_decode($data, true);//convert to array

		// $subscriberId = $arr_data['subscriberId'];
		// $frequency = $arr_data['frequency'];
		// $status = $arr_data['status'];
  //   }
}
