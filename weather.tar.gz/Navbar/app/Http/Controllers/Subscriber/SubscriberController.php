<?php

namespace App\Http\Controllers\Subscriber;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Model\SubscriberModel;

class SubscriberController extends Controller
{
    //function to save data from post request (Postman Body raw) into database
    public function saveSubscriber(Request $req){

    	$subscriber = new SubscriberModel;

 
    		$subscriber->subscriberID = $req->input('subscriberId');
	    	$subscriber->frequency = $req->input('frequency');
	    	$subscriber->statu_s = $req->input('status');

			$subscriber->save();
			echo "OK";

  		//$subscriber->subscriberID = $req->input('subscriberId');
  		//$subscriber->frequency = $req->input('frequency');
  		//$subscriber->statu_s = $req->input('status');

		// $subscriber->save();
		// echo "OK";
    }
}
