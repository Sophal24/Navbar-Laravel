<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Weather;

class WeatherController extends Controller
{

    //function to show all data (in) from Weather database
    public function showall(){
    	$data = Weather::all();
    	print_r($data);
    	

    }

    public function showsome(){
    	$data = Weather::all();
    	
    	echo "<h2>Weather Data History</h2>";

    	foreach ($data as $value) {
    		# code...
    		echo $value->id."-".$value->date."-".$value->min_tem."-".$value->max_tem."-".$value->day."-".$value->night."-".$value->humidity."-".$value->wind."-".$value->current_tem." "."<br>";
    	}
    }
    
}
